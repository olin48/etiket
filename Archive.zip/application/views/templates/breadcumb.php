<!-- Breadcrumb -->
<div class="sub-board">
    <span class="header-icon"><i class="fontello-home"></i>
    </span>
    <ol class="breadcrumb newcrumb ng-scope">
        <li>
            <a href="#">
                <span>
                </span>Dashboard</a>
        </li>

    </ol>
    <div class="dark" style="visibility: visible;">
        <form class="navbar-form navbar-left" role="search">
            <div class="form-group">
                <input type="text" class="form-control search rounded id_search" placeholder="Search">
            </div>
        </form>
    </div>
</div>
<!-- End of Breadcrumb -->